package Pages;

public class CheckoutPage {

}
