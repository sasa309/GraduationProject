package Components;

public class Footer {

}
