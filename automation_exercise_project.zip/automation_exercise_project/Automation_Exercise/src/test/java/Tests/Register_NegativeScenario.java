package Tests;

public class Register_NegativeScenario {

	
	private void register_WithInvalidEmail() {
		// TODO Auto-generated method stub

	}
	
	private void register_WithExistEmail() {
		// TODO Auto-generated method stub

	}
	
	private void register_WithInvalidFeilds() {
		// TODO Auto-generated method stub

	}
}
