package Tests;

public class Login_HappyScenario extends BaseTest{

	
	public void user() {
		
	}
}
