package Tests;

public class Checkout_HappyScenario {
	checkout_After_Login();
	checkout_After_AddingProductToCart();
	checkout_After_RemovnigOneProductFromCart();
}
