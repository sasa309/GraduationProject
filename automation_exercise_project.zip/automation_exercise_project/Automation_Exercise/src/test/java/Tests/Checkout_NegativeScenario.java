package Tests;

public class Checkout_NegativeScenario {
	checkout_By_NotLoggedUser();
	checkout_EmptyCart();
	checkout_After_RemovingAllProductsInCart();
}
